//cmd prompt - npm install ejs; npm install express

var express = require("express");
var app = express();

// gets

//default root address and index page
app.get('/', function(request, response) {
  response.render('index');
})

app.get('/cars.html', function(request, response) {
  response.render('cars');
})

app.get('/cats.html', function(request, response) {
  response.render('cats');
})

app.get('/form.html', function(request, response) {
  response.render('form');
})

// listener

app.listen(8000, function() {
  console.log('listening to port 8000');
})

// setter

app.set('views', __dirname + '/views');
app.set('view engine', 'ejs');

// uses

app.use(express.static(__dirname + '/static/images'));
